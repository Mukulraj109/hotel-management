import RoomTypeAllotment from '../models/RoomTypeAllotment.js';
import allotmentService from '../services/allotmentService.js';
import { validationResult } from 'express-validator';

const allotmentController = {
  /**
   * Create a new room type allotment configuration
   */
  async createAllotment(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const allotmentData = {
        ...req.body,
        hotelId: req.user.hotelId
      };

      const allotment = await allotmentService.createAllotment(allotmentData, req.user.id);

      res.status(201).json({
        success: true,
        data: allotment,
        message: 'Room type allotment created successfully'
      });
    } catch (error) {
      console.error('Error creating allotment:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to create allotment',
        message: error.message
      });
    }
  },

  /**
   * Get all allotments for a hotel
   */
  async getAllotments(req, res) {
    try {
      const { 
        page = 1, 
        limit = 10, 
        status, 
        roomTypeId,
        search,
        sortBy = 'createdAt',
        sortOrder = 'desc'
      } = req.query;

      const filter = { hotelId: req.user.hotelId };
      
      if (status && status !== 'all') {
        filter.status = status;
      }
      
      if (roomTypeId) {
        filter.roomTypeId = roomTypeId;
      }
      
      if (search) {
        filter.$or = [
          { name: { $regex: search, $options: 'i' } },
          { description: { $regex: search, $options: 'i' } }
        ];
      }

      const skip = (page - 1) * limit;
      const sort = {};
      sort[sortBy] = sortOrder === 'desc' ? -1 : 1;

      const allotments = await RoomTypeAllotment.find(filter)
        .populate('roomTypeId', 'name code maxOccupancy baseRate')
        .populate('createdBy', 'name email')
        .populate('updatedBy', 'name email')
        .sort(sort)
        .skip(skip)
        .limit(parseInt(limit));

      const total = await RoomTypeAllotment.countDocuments(filter);

      res.json({
        success: true,
        data: {
          allotments,
          pagination: {
            current: parseInt(page),
            pages: Math.ceil(total / limit),
            total,
            limit: parseInt(limit)
          }
        }
      });
    } catch (error) {
      console.error('Error fetching allotments:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to fetch allotments',
        message: error.message
      });
    }
  },

  /**
   * Get a specific allotment by ID
   */
  async getAllotment(req, res) {
    try {
      const { id } = req.params;
      const allotment = await RoomTypeAllotment.findOne({
        _id: id,
        hotelId: req.user.hotelId
      })
      .populate('roomTypeId', 'name code maxOccupancy baseRate')
      .populate('createdBy', 'name email')
      .populate('updatedBy', 'name email');

      if (!allotment) {
        return res.status(404).json({
          success: false,
          error: 'Allotment not found'
        });
      }

      res.json({
        success: true,
        data: allotment
      });
    } catch (error) {
      console.error('Error fetching allotment:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to fetch allotment',
        message: error.message
      });
    }
  },

  /**
   * Update an allotment configuration
   */
  async updateAllotment(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const { id } = req.params;
      const updateData = {
        ...req.body,
        updatedBy: req.user.id,
        updatedAt: new Date()
      };

      const allotment = await RoomTypeAllotment.findOneAndUpdate(
        { _id: id, hotelId: req.user.hotelId },
        updateData,
        { new: true, runValidators: true }
      );

      if (!allotment) {
        return res.status(404).json({
          success: false,
          error: 'Allotment not found'
        });
      }

      // Log the update
      await allotmentService.logAction(id, req.user.id, 'updated', { changes: updateData });

      res.json({
        success: true,
        data: allotment,
        message: 'Allotment updated successfully'
      });
    } catch (error) {
      console.error('Error updating allotment:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to update allotment',
        message: error.message
      });
    }
  },

  /**
   * Delete an allotment configuration
   */
  async deleteAllotment(req, res) {
    try {
      const { id } = req.params;
      const allotment = await RoomTypeAllotment.findOneAndUpdate(
        { _id: id, hotelId: req.user.hotelId },
        { status: 'inactive', updatedBy: req.user.id },
        { new: true }
      );

      if (!allotment) {
        return res.status(404).json({
          success: false,
          error: 'Allotment not found'
        });
      }

      // Log the deletion
      await allotmentService.logAction(id, req.user.id, 'deleted', { previousStatus: allotment.status });

      res.json({
        success: true,
        message: 'Allotment deleted successfully'
      });
    } catch (error) {
      console.error('Error deleting allotment:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to delete allotment',
        message: error.message
      });
    }
  },

  /**
   * Get allotments for a specific date range
   */
  async getAllotmentsByDateRange(req, res) {
    try {
      const { startDate, endDate, roomTypeId } = req.query;

      if (!startDate || !endDate) {
        return res.status(400).json({
          success: false,
          error: 'Start date and end date are required'
        });
      }

      const filter = { hotelId: req.user.hotelId, status: 'active' };
      if (roomTypeId) {
        filter.roomTypeId = roomTypeId;
      }

      const allotments = await RoomTypeAllotment.find(filter)
        .populate('roomTypeId', 'name code')
        .lean();

      // Filter and format daily allotments for the date range
      const start = new Date(startDate);
      const end = new Date(endDate);

      const result = allotments.map(allotment => ({
        ...allotment,
        dailyAllotments: allotment.dailyAllotments.filter(day => {
          const dayDate = new Date(day.date);
          return dayDate >= start && dayDate <= end;
        }).sort((a, b) => new Date(a.date) - new Date(b.date))
      }));

      res.json({
        success: true,
        data: result
      });
    } catch (error) {
      console.error('Error fetching allotments by date range:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to fetch allotments',
        message: error.message
      });
    }
  },

  /**
   * Apply allocation rule to a date range
   */
  async applyAllocationRule(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const { id } = req.params;
      const { ruleId, startDate, endDate } = req.body;

      // Verify allotment belongs to user's hotel
      const allotment = await RoomTypeAllotment.findOne({
        _id: id,
        hotelId: req.user.hotelId
      });

      if (!allotment) {
        return res.status(404).json({
          success: false,
          error: 'Allotment not found'
        });
      }

      const result = await allotmentService.applyAllocationRule(
        id, 
        ruleId, 
        { startDate, endDate }, 
        req.user.id
      );

      res.json({
        success: true,
        data: result,
        message: `Allocation rule applied to ${result.daysProcessed} days`
      });
    } catch (error) {
      console.error('Error applying allocation rule:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to apply allocation rule',
        message: error.message
      });
    }
  },

  /**
   * Update channel allocation for a specific date
   */
  async updateChannelAllocation(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const { id } = req.params;
      const { channelId, date, allocated, sold, blocked } = req.body;

      const allotment = await RoomTypeAllotment.findOne({
        _id: id,
        hotelId: req.user.hotelId
      });

      if (!allotment) {
        return res.status(404).json({
          success: false,
          error: 'Allotment not found'
        });
      }

      // Update the allocation
      const allocation = {};
      if (allocated !== undefined) allocation.allocated = allocated;
      if (sold !== undefined) allocation.sold = sold;
      if (blocked !== undefined) allocation.blocked = blocked;

      allotment.updateChannelAllocation(channelId, date, allocation);
      await allotment.save();

      // Log the update
      await allotmentService.logAction(id, req.user.id, 'updated', {
        channelId,
        date,
        allocation
      });

      res.json({
        success: true,
        message: 'Channel allocation updated successfully',
        data: allotment.getAllotmentForDate(date)
      });
    } catch (error) {
      console.error('Error updating channel allocation:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to update channel allocation',
        message: error.message
      });
    }
  },

  /**
   * Process a booking (allocate rooms)
   */
  async processBooking(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const bookingData = {
        ...req.body,
        hotelId: req.user.hotelId
      };

      const result = await allotmentService.processBooking(bookingData);

      res.json({
        success: true,
        data: result,
        message: 'Booking processed successfully'
      });
    } catch (error) {
      console.error('Error processing booking:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to process booking',
        message: error.message
      });
    }
  },

  /**
   * Release rooms (cancellation)
   */
  async releaseRooms(req, res) {
    try {
      const errors = validationResult(req);
      if (!errors.isEmpty()) {
        return res.status(400).json({
          success: false,
          error: 'Validation failed',
          details: errors.array()
        });
      }

      const releaseData = {
        ...req.body,
        hotelId: req.user.hotelId,
        userId: req.user.id
      };

      const result = await allotmentService.releaseRooms(releaseData);

      res.json({
        success: true,
        data: result,
        message: 'Rooms released successfully'
      });
    } catch (error) {
      console.error('Error releasing rooms:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to release rooms',
        message: error.message
      });
    }
  },

  /**
   * Get analytics for an allotment
   */
  async getAnalytics(req, res) {
    try {
      const { id } = req.params;
      const { 
        startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
        endDate = new Date().toISOString(),
        groupBy = 'day'
      } = req.query;

      // Verify allotment belongs to user's hotel
      const allotment = await RoomTypeAllotment.findOne({
        _id: id,
        hotelId: req.user.hotelId
      });

      if (!allotment) {
        return res.status(404).json({
          success: false,
          error: 'Allotment not found'
        });
      }

      const analytics = await allotmentService.generateAnalytics(id, {
        startDate: new Date(startDate),
        endDate: new Date(endDate)
      });

      res.json({
        success: true,
        data: analytics
      });
    } catch (error) {
      console.error('Error fetching analytics:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to fetch analytics',
        message: error.message
      });
    }
  },

  /**
   * Get channel performance summary
   */
  async getChannelPerformance(req, res) {
    try {
      const { id } = req.params;
      const { 
        startDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        endDate = new Date().toISOString()
      } = req.query;

      const allotment = await RoomTypeAllotment.findOne({
        _id: id,
        hotelId: req.user.hotelId
      });

      if (!allotment) {
        return res.status(404).json({
          success: false,
          error: 'Allotment not found'
        });
      }

      // Get performance data for each channel
      const channelPerformance = [];
      
      for (const channel of allotment.channels) {
        if (channel.isActive) {
          const performance = await allotmentService.getChannelPerformance(
            id, 
            channel.channelId, 
            new Date(endDate)
          );

          channelPerformance.push({
            channelId: channel.channelId,
            channelName: channel.channelName,
            priority: channel.priority,
            commission: channel.commission,
            isActive: channel.isActive,
            performance
          });
        }
      }

      res.json({
        success: true,
        data: {
          period: { startDate, endDate },
          channels: channelPerformance
        }
      });
    } catch (error) {
      console.error('Error fetching channel performance:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to fetch channel performance',
        message: error.message
      });
    }
  },

  /**
   * Optimize allocations based on performance
   */
  async optimizeAllocations(req, res) {
    try {
      const { id } = req.params;

      // Verify allotment belongs to user's hotel
      const allotment = await RoomTypeAllotment.findOne({
        _id: id,
        hotelId: req.user.hotelId
      });

      if (!allotment) {
        return res.status(404).json({
          success: false,
          error: 'Allotment not found'
        });
      }

      const result = await allotmentService.optimizeAllocations(id, req.user.id);

      res.json({
        success: true,
        data: result,
        message: 'Allocations optimized successfully'
      });
    } catch (error) {
      console.error('Error optimizing allocations:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to optimize allocations',
        message: error.message
      });
    }
  },

  /**
   * Get availability for a date range and room type
   */
  async getAvailability(req, res) {
    try {
      const { roomTypeId, startDate, endDate, channelId } = req.query;

      if (!roomTypeId || !startDate || !endDate) {
        return res.status(400).json({
          success: false,
          error: 'Room type ID, start date, and end date are required'
        });
      }

      const allotment = await RoomTypeAllotment.findOne({
        hotelId: req.user.hotelId,
        roomTypeId,
        status: 'active'
      });

      if (!allotment) {
        return res.status(404).json({
          success: false,
          error: 'No active allotment found for this room type'
        });
      }

      const start = new Date(startDate);
      const end = new Date(endDate);
      const availability = [];

      for (let date = new Date(start); date <= end; date.setDate(date.getDate() + 1)) {
        const dailyAllotment = allotment.getAllotmentForDate(date);
        
        if (dailyAllotment) {
          const dateAvailability = {
            date: new Date(date),
            totalInventory: dailyAllotment.totalInventory,
            totalSold: dailyAllotment.totalSold,
            freeStock: dailyAllotment.freeStock,
            occupancyRate: dailyAllotment.occupancyRate,
            channels: dailyAllotment.channelAllotments.map(channel => ({
              channelId: channel.channelId,
              allocated: channel.allocated,
              sold: channel.sold,
              available: channel.available,
              blocked: channel.blocked
            }))
          };

          // If specific channel requested, filter
          if (channelId) {
            const channelData = dailyAllotment.channelAllotments.find(c => c.channelId === channelId);
            if (channelData) {
              dateAvailability.channelAvailable = channelData.available;
            } else {
              dateAvailability.channelAvailable = 0;
            }
          }

          availability.push(dateAvailability);
        } else {
          availability.push({
            date: new Date(date),
            totalInventory: allotment.defaultSettings.totalInventory,
            totalSold: 0,
            freeStock: allotment.defaultSettings.totalInventory,
            occupancyRate: 0,
            channels: [],
            channelAvailable: channelId ? 0 : undefined
          });
        }
      }

      res.json({
        success: true,
        data: {
          roomTypeId,
          period: { startDate, endDate },
          channelId: channelId || 'all',
          availability
        }
      });
    } catch (error) {
      console.error('Error fetching availability:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to fetch availability',
        message: error.message
      });
    }
  },

  /**
   * Get allotment recommendations
   */
  async getRecommendations(req, res) {
    try {
      const { id } = req.params;

      const allotment = await RoomTypeAllotment.findOne({
        _id: id,
        hotelId: req.user.hotelId
      });

      if (!allotment) {
        return res.status(404).json({
          success: false,
          error: 'Allotment not found'
        });
      }

      // Generate fresh recommendations
      allotment.generateRecommendations();
      await allotment.save();

      res.json({
        success: true,
        data: {
          recommendations: allotment.analytics.recommendations,
          lastUpdated: new Date(),
          totalRecommendations: allotment.analytics.recommendations.length
        }
      });
    } catch (error) {
      console.error('Error fetching recommendations:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to fetch recommendations',
        message: error.message
      });
    }
  },

  /**
   * Export allotment data
   */
  async exportAllotment(req, res) {
    try {
      const { id } = req.params;
      const { format = 'json', startDate, endDate } = req.query;

      const allotment = await RoomTypeAllotment.findOne({
        _id: id,
        hotelId: req.user.hotelId
      })
      .populate('roomTypeId', 'name code')
      .lean();

      if (!allotment) {
        return res.status(404).json({
          success: false,
          error: 'Allotment not found'
        });
      }

      // Filter by date range if provided
      if (startDate && endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);
        allotment.dailyAllotments = allotment.dailyAllotments.filter(day => {
          const dayDate = new Date(day.date);
          return dayDate >= start && dayDate <= end;
        });
      }

      let exportData;
      let contentType;
      let filename;

      switch (format) {
        case 'csv':
          exportData = this.convertToCSV(allotment);
          contentType = 'text/csv';
          filename = `allotment-${allotment.name}-${new Date().toISOString().split('T')[0]}.csv`;
          break;
        case 'json':
        default:
          exportData = JSON.stringify(allotment, null, 2);
          contentType = 'application/json';
          filename = `allotment-${allotment.name}-${new Date().toISOString().split('T')[0]}.json`;
          break;
      }

      res.setHeader('Content-Type', contentType);
      res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
      res.send(exportData);
    } catch (error) {
      console.error('Error exporting allotment:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to export allotment',
        message: error.message
      });
    }
  },

  /**
   * Convert allotment data to CSV format
   */
  convertToCSV(allotment) {
    const headers = [
      'Date',
      'Total Inventory',
      'Total Sold',
      'Free Stock',
      'Occupancy Rate',
      'Channel',
      'Allocated',
      'Sold',
      'Available',
      'Blocked'
    ];

    const rows = [];
    
    allotment.dailyAllotments.forEach(day => {
      day.channelAllotments.forEach(channel => {
        rows.push([
          new Date(day.date).toISOString().split('T')[0],
          day.totalInventory,
          day.totalSold,
          day.freeStock,
          `${day.occupancyRate}%`,
          channel.channelId,
          channel.allocated,
          channel.sold,
          channel.available,
          channel.blocked
        ]);
      });
    });

    return [headers, ...rows]
      .map(row => row.map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(','))
      .join('\n');
  },

  /**
   * Get allotment summary dashboard data
   */
  async getDashboard(req, res) {
    try {
      const hotelId = req.user.hotelId;
      const today = new Date();
      const thirtyDaysAgo = new Date(today.getTime() - 30 * 24 * 60 * 60 * 1000);

      // Get all active allotments
      const allotments = await RoomTypeAllotment.find({
        hotelId,
        status: 'active'
      })
      .populate('roomTypeId', 'name code')
      .lean();

      // Calculate summary metrics
      const summary = {
        totalAllotments: allotments.length,
        totalRoomTypes: new Set(allotments.map(a => a.roomTypeId._id.toString())).size,
        totalChannels: 0,
        averageOccupancyRate: 0,
        totalRevenue: 0,
        topPerformingChannel: null,
        lowUtilizationChannels: [],
        recentRecommendations: []
      };

      let totalOccupancy = 0;
      let occupancyCount = 0;
      const channelPerformance = new Map();

      // Process each allotment
      for (const allotment of allotments) {
        // Count unique channels
        allotment.channels.forEach(channel => {
          if (channel.isActive) {
            channelPerformance.set(channel.channelId, {
              channelName: channel.channelName,
              totalAllocated: 0,
              totalSold: 0,
              revenue: 0
            });
          }
        });

        // Process recent daily allotments
        const recentAllotments = allotment.dailyAllotments.filter(day => {
          const dayDate = new Date(day.date);
          return dayDate >= thirtyDaysAgo && dayDate <= today;
        });

        recentAllotments.forEach(day => {
          totalOccupancy += day.occupancyRate;
          occupancyCount++;

          day.channelAllotments.forEach(channel => {
            if (channelPerformance.has(channel.channelId)) {
              const perf = channelPerformance.get(channel.channelId);
              perf.totalAllocated += channel.allocated;
              perf.totalSold += channel.sold;
            }
          });
        });

        // Collect recommendations
        if (allotment.analytics && allotment.analytics.recommendations) {
          summary.recentRecommendations.push(...allotment.analytics.recommendations.slice(-3));
        }
      }

      // Calculate averages and find top performers
      summary.totalChannels = channelPerformance.size;
      summary.averageOccupancyRate = occupancyCount > 0 ? Math.round((totalOccupancy / occupancyCount) * 100) / 100 : 0;

      // Find top performing and low utilization channels
      const sortedChannels = Array.from(channelPerformance.entries())
        .map(([channelId, data]) => ({
          channelId,
          ...data,
          utilizationRate: data.totalAllocated > 0 ? (data.totalSold / data.totalAllocated) * 100 : 0
        }))
        .sort((a, b) => b.utilizationRate - a.utilizationRate);

      if (sortedChannels.length > 0) {
        summary.topPerformingChannel = sortedChannels[0];
        summary.lowUtilizationChannels = sortedChannels.filter(c => c.utilizationRate < 50).slice(0, 3);
      }

      // Sort recent recommendations by priority
      summary.recentRecommendations = summary.recentRecommendations
        .sort((a, b) => {
          const priorityOrder = { critical: 4, high: 3, medium: 2, low: 1 };
          return priorityOrder[b.priority] - priorityOrder[a.priority];
        })
        .slice(0, 5);

      res.json({
        success: true,
        data: summary
      });
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      res.status(500).json({
        success: false,
        error: 'Failed to fetch dashboard data',
        message: error.message
      });
    }
  }
};

export default allotmentController;