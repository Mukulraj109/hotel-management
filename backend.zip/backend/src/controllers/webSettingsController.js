import WebSettings from '../models/WebSettings.js';
import AuditLog from '../models/AuditLog.js';
import mongoose from 'mongoose';

class WebSettingsController {
  /**
   * Get web settings for a hotel
   */
  async getSettings(req, res) {
    try {
      const { hotelId } = req.params;

      if (!hotelId) {
        return res.status(400).json({
          success: false,
          message: 'Hotel ID is required'
        });
      }

      const settings = await WebSettings.getActiveSettings(hotelId);

      if (!settings) {
        // Create default settings if none exist
        const newSettings = await WebSettings.createDefaultSettings(hotelId, req.user.id);
        return res.json({
          success: true,
          data: newSettings,
          message: 'Default settings created'
        });
      }

      res.json({
        success: true,
        data: settings
      });

    } catch (error) {
      console.error('Error getting web settings:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to retrieve web settings',
        error: error.message
      });
    }
  }

  /**
   * Update web settings
   */
  async updateSettings(req, res) {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      const { hotelId } = req.params;
      const updateData = req.body;

      if (!hotelId) {
        return res.status(400).json({
          success: false,
          message: 'Hotel ID is required'
        });
      }

      // Validate required fields
      if (updateData.general && !updateData.general.hotelName) {
        return res.status(400).json({
          success: false,
          message: 'Hotel name is required'
        });
      }

      // Create backup of current settings
      const currentSettings = await WebSettings.getActiveSettings(hotelId);
      if (currentSettings) {
        const backup = currentSettings.createBackup();
        
        // Log settings change
        await AuditLog.logSettingsChange(currentSettings, 'web_settings_update', req.user.id, {
          source: 'web_settings_controller',
          backup: backup,
          changes: updateData
        });
      }

      // Update or create settings
      const settings = await WebSettings.findOneAndUpdate(
        { hotelId, isActive: true },
        {
          ...updateData,
          updatedBy: req.user.id,
          updatedAt: new Date()
        },
        {
          new: true,
          upsert: true,
          runValidators: true,
          session
        }
      ).populate('createdBy updatedBy', 'name email');

      await session.commitTransaction();

      res.json({
        success: true,
        data: settings,
        message: 'Web settings updated successfully'
      });

    } catch (error) {
      await session.abortTransaction();
      console.error('Error updating web settings:', error);

      if (error.name === 'ValidationError') {
        const messages = Object.values(error.errors).map(err => err.message);
        return res.status(400).json({
          success: false,
          message: 'Validation error',
          errors: messages
        });
      }

      res.status(500).json({
        success: false,
        message: 'Failed to update web settings',
        error: error.message
      });
    } finally {
      session.endSession();
    }
  }

  /**
   * Update specific settings section
   */
  async updateSection(req, res) {
    try {
      const { hotelId, section } = req.params;
      const updateData = req.body;

      const validSections = ['general', 'booking', 'payment', 'seo', 'integrations', 'theme', 'advanced', 'maintenance'];
      
      if (!validSections.includes(section)) {
        return res.status(400).json({
          success: false,
          message: 'Invalid settings section'
        });
      }

      const settings = await WebSettings.findOneAndUpdate(
        { hotelId, isActive: true },
        {
          $set: {
            [`${section}`]: updateData,
            updatedBy: req.user.id,
            updatedAt: new Date()
          }
        },
        {
          new: true,
          runValidators: true
        }
      ).populate('createdBy updatedBy', 'name email');

      if (!settings) {
        return res.status(404).json({
          success: false,
          message: 'Settings not found'
        });
      }

      // Log section update
      await AuditLog.logSettingsChange(settings, `web_settings_section_update_${section}`, req.user.id, {
        source: 'web_settings_controller',
        section: section,
        changes: updateData
      });

      res.json({
        success: true,
        data: settings,
        message: `${section} settings updated successfully`
      });

    } catch (error) {
      console.error('Error updating settings section:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to update settings section',
        error: error.message
      });
    }
  }

  /**
   * Test settings configuration (e.g., payment gateway, email, etc.)
   */
  async testSettings(req, res) {
    try {
      const { hotelId } = req.params;
      const { type, config } = req.body;

      const settings = await WebSettings.getActiveSettings(hotelId);
      if (!settings) {
        return res.status(404).json({
          success: false,
          message: 'Settings not found'
        });
      }

      let testResult = { success: false, message: 'Test not implemented' };

      switch (type) {
        case 'payment_gateway':
          testResult = await this.testPaymentGateway(config);
          break;
        case 'email_marketing':
          testResult = await this.testEmailMarketing(config);
          break;
        case 'google_analytics':
          testResult = await this.testGoogleAnalytics(config);
          break;
        case 'facebook_pixel':
          testResult = await this.testFacebookPixel(config);
          break;
        default:
          return res.status(400).json({
            success: false,
            message: 'Invalid test type'
          });
      }

      res.json({
        success: true,
        data: testResult
      });

    } catch (error) {
      console.error('Error testing settings:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to test settings',
        error: error.message
      });
    }
  }

  /**
   * Export settings
   */
  async exportSettings(req, res) {
    try {
      const { hotelId } = req.params;
      const { format = 'json' } = req.query;

      const settings = await WebSettings.getActiveSettings(hotelId);
      if (!settings) {
        return res.status(404).json({
          success: false,
          message: 'Settings not found'
        });
      }

      // Create sanitized export (remove sensitive data)
      const exportData = settings.toObject();
      
      // Remove sensitive information
      if (exportData.payment && exportData.payment.gateways) {
        exportData.payment.gateways = exportData.payment.gateways.map(gateway => ({
          ...gateway,
          configuration: {} // Remove sensitive config
        }));
      }

      if (exportData.integrations) {
        const sensitiveFields = ['apiKey', 'trackingId', 'measurementId', 'pixelId'];
        sensitiveFields.forEach(field => {
          Object.keys(exportData.integrations).forEach(key => {
            if (exportData.integrations[key] && exportData.integrations[key][field]) {
              exportData.integrations[key][field] = '***REDACTED***';
            }
          });
        });
      }

      // Log export activity
      await AuditLog.logSettingsChange(settings, 'web_settings_export', req.user.id, {
        source: 'web_settings_controller',
        format: format,
        exportTime: new Date()
      });

      if (format === 'json') {
        res.json({
          success: true,
          data: exportData,
          exportedAt: new Date(),
          version: settings.version
        });
      } else {
        return res.status(400).json({
          success: false,
          message: 'Unsupported export format'
        });
      }

    } catch (error) {
      console.error('Error exporting settings:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to export settings',
        error: error.message
      });
    }
  }

  /**
   * Import settings
   */
  async importSettings(req, res) {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      const { hotelId } = req.params;
      const importData = req.body;

      // Validate import data structure
      if (!importData || typeof importData !== 'object') {
        return res.status(400).json({
          success: false,
          message: 'Invalid import data'
        });
      }

      // Create backup before import
      const currentSettings = await WebSettings.getActiveSettings(hotelId);
      if (currentSettings) {
        const backup = currentSettings.createBackup();
        
        await AuditLog.logSettingsChange(currentSettings, 'web_settings_import', req.user.id, {
          source: 'web_settings_controller',
          backup: backup,
          importData: importData
        });
      }

      // Remove sensitive fields from import data (user must manually configure)
      delete importData._id;
      delete importData.__v;
      delete importData.createdAt;
      delete importData.updatedAt;
      delete importData.createdBy;
      delete importData.updatedBy;

      // Import settings
      const settings = await WebSettings.importSettings(hotelId, importData, req.user.id);

      await session.commitTransaction();

      res.json({
        success: true,
        data: settings,
        message: 'Settings imported successfully'
      });

    } catch (error) {
      await session.abortTransaction();
      console.error('Error importing settings:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to import settings',
        error: error.message
      });
    } finally {
      session.endSession();
    }
  }

  /**
   * Get settings preview
   */
  async previewSettings(req, res) {
    try {
      const { hotelId } = req.params;
      const previewData = req.body;

      const currentSettings = await WebSettings.getActiveSettings(hotelId);
      if (!currentSettings) {
        return res.status(404).json({
          success: false,
          message: 'Settings not found'
        });
      }

      // Merge current settings with preview data
      const previewSettings = {
        ...currentSettings.toObject(),
        ...previewData
      };

      // Generate preview metadata
      const preview = {
        settings: previewSettings,
        metadata: {
          previewId: new mongoose.Types.ObjectId(),
          createdAt: new Date(),
          expiresAt: new Date(Date.now() + 3600000), // 1 hour
          changes: this.getChanges(currentSettings.toObject(), previewData)
        }
      };

      res.json({
        success: true,
        data: preview
      });

    } catch (error) {
      console.error('Error generating settings preview:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to generate preview',
        error: error.message
      });
    }
  }

  /**
   * Reset settings to default
   */
  async resetToDefault(req, res) {
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      const { hotelId } = req.params;

      // Create backup
      const currentSettings = await WebSettings.getActiveSettings(hotelId);
      if (currentSettings) {
        const backup = currentSettings.createBackup();
        
        await AuditLog.logSettingsChange(currentSettings, 'web_settings_reset', req.user.id, {
          source: 'web_settings_controller',
          backup: backup,
          resetTime: new Date()
        });
      }

      // Delete existing settings
      await WebSettings.deleteMany({ hotelId }, { session });

      // Create new default settings
      const defaultSettings = await WebSettings.createDefaultSettings(hotelId, req.user.id);

      await session.commitTransaction();

      res.json({
        success: true,
        data: defaultSettings,
        message: 'Settings reset to default successfully'
      });

    } catch (error) {
      await session.abortTransaction();
      console.error('Error resetting settings:', error);
      res.status(500).json({
        success: false,
        message: 'Failed to reset settings',
        error: error.message
      });
    } finally {
      session.endSession();
    }
  }

  // Helper methods

  async testPaymentGateway(config) {
    // Implement payment gateway testing logic
    return { success: true, message: 'Payment gateway connection successful' };
  }

  async testEmailMarketing(config) {
    // Implement email marketing testing logic
    return { success: true, message: 'Email marketing connection successful' };
  }

  async testGoogleAnalytics(config) {
    // Implement Google Analytics testing logic
    return { success: true, message: 'Google Analytics connection successful' };
  }

  async testFacebookPixel(config) {
    // Implement Facebook Pixel testing logic
    return { success: true, message: 'Facebook Pixel connection successful' };
  }

  getChanges(original, updated) {
    const changes = [];
    
    const compareObjects = (obj1, obj2, path = '') => {
      for (const key in obj2) {
        const currentPath = path ? `${path}.${key}` : key;
        
        if (obj1[key] !== obj2[key]) {
          if (typeof obj2[key] === 'object' && obj2[key] !== null && !Array.isArray(obj2[key])) {
            compareObjects(obj1[key] || {}, obj2[key], currentPath);
          } else {
            changes.push({
              field: currentPath,
              oldValue: obj1[key],
              newValue: obj2[key]
            });
          }
        }
      }
    };

    compareObjects(original, updated);
    return changes;
  }
}

export default new WebSettingsController();