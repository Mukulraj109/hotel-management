import express from 'express';
import { body, param, query, validationResult } from 'express-validator';
import webSettingsController from '../controllers/webSettingsController.js';
import { authenticate } from '../middleware/auth.js';
import { requireRole } from '../middleware/roleAuth.js';

const router = express.Router();

// Middleware to check for validation errors
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({
      success: false,
      message: 'Validation error',
      errors: errors.array()
    });
  }
  next();
};

// Apply authentication and admin role requirement to all routes
router.use(authenticate);
router.use(requireRole(['admin']));

// GET /api/v1/web-settings/:hotelId - Get web settings for hotel
router.get('/:hotelId',
  [
    param('hotelId').isMongoId().withMessage('Valid hotel ID is required')
  ],
  handleValidationErrors,
  webSettingsController.getSettings
);

// PUT /api/v1/web-settings/:hotelId - Update web settings
router.put('/:hotelId',
  [
    param('hotelId').isMongoId().withMessage('Valid hotel ID is required'),
    body('general.hotelName').optional().isLength({ min: 1, max: 200 }).withMessage('Hotel name must be 1-200 characters'),
    body('general.description').optional().isLength({ max: 1000 }).withMessage('Description must not exceed 1000 characters'),
    body('general.contact.email').optional().isEmail().withMessage('Valid email is required'),
    body('general.contact.phone').optional().isLength({ min: 10, max: 20 }).withMessage('Phone must be 10-20 characters'),
    body('general.timezone').optional().isString().withMessage('Timezone must be a string'),
    body('general.currency.code').optional().isLength({ min: 3, max: 3 }).withMessage('Currency code must be 3 characters'),
    
    // Booking settings validation
    body('booking.minimumStay').optional().isInt({ min: 1, max: 365 }).withMessage('Minimum stay must be 1-365 days'),
    body('booking.maximumStay').optional().isInt({ min: 1, max: 365 }).withMessage('Maximum stay must be 1-365 days'),
    body('booking.advanceBookingLimit').optional().isInt({ min: 1, max: 1095 }).withMessage('Advance booking limit must be 1-1095 days'),
    body('booking.cutoffTime.hours').optional().isInt({ min: 0, max: 23 }).withMessage('Cutoff hours must be 0-23'),
    body('booking.cutoffTime.minutes').optional().isInt({ min: 0, max: 59 }).withMessage('Cutoff minutes must be 0-59'),
    body('booking.cancellationPolicy.type').optional().isIn(['flexible', 'moderate', 'strict', 'custom']).withMessage('Invalid cancellation policy type'),
    body('booking.cancellationPolicy.penaltyPercentage').optional().isFloat({ min: 0, max: 100 }).withMessage('Penalty percentage must be 0-100'),
    body('booking.checkInTime').optional().matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/).withMessage('Check-in time must be in HH:MM format'),
    body('booking.checkOutTime').optional().matches(/^([01]?[0-9]|2[0-3]):[0-5][0-9]$/).withMessage('Check-out time must be in HH:MM format'),
    
    // Payment settings validation
    body('payment.gateways').optional().isArray().withMessage('Payment gateways must be an array'),
    body('payment.gateways.*.name').optional().isIn(['stripe', 'paypal', 'razorpay', 'square', 'authorize_net', 'braintree']).withMessage('Invalid payment gateway name'),
    body('payment.gateways.*.fees.percentage').optional().isFloat({ min: 0, max: 10 }).withMessage('Gateway fee percentage must be 0-10'),
    body('payment.gateways.*.fees.fixed').optional().isFloat({ min: 0 }).withMessage('Gateway fixed fee must be non-negative'),
    body('payment.depositAmount.value').optional().isFloat({ min: 0 }).withMessage('Deposit amount must be non-negative'),
    
    // SEO settings validation
    body('seo.metaTags.title').optional().isLength({ max: 60 }).withMessage('Meta title must not exceed 60 characters'),
    body('seo.metaTags.description').optional().isLength({ max: 160 }).withMessage('Meta description must not exceed 160 characters'),
    body('seo.metaTags.keywords').optional().isArray().withMessage('Keywords must be an array'),
    
    // Integration settings validation
    body('integrations.googleAnalytics.trackingId').optional().matches(/^UA-\d+-\d+$|^G-[A-Z0-9]+$/).withMessage('Invalid Google Analytics tracking ID'),
    body('integrations.googleTagManager.containerId').optional().matches(/^GTM-[A-Z0-9]+$/).withMessage('Invalid Google Tag Manager container ID'),
    body('integrations.facebookPixel.pixelId').optional().isNumeric().withMessage('Facebook Pixel ID must be numeric'),
    body('integrations.emailMarketing.provider').optional().isIn(['mailchimp', 'sendgrid', 'constant_contact', 'campaign_monitor', 'none']).withMessage('Invalid email marketing provider'),
    body('integrations.chatWidget.provider').optional().isIn(['intercom', 'zendesk', 'tawk_to', 'crisp', 'none']).withMessage('Invalid chat widget provider'),
    
    // Theme settings validation
    body('theme.colorScheme.primary').optional().matches(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/).withMessage('Primary color must be a valid hex code'),
    body('theme.colorScheme.secondary').optional().matches(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/).withMessage('Secondary color must be a valid hex code'),
    body('theme.typography.primaryFont').optional().isString().withMessage('Primary font must be a string'),
    body('theme.layout.maxWidth').optional().isString().withMessage('Max width must be a string'),
    body('theme.customCSS').optional().isLength({ max: 10000 }).withMessage('Custom CSS must not exceed 10,000 characters'),
    
    // Advanced settings validation
    body('advanced.caching.ttl').optional().isInt({ min: 60, max: 86400 }).withMessage('Cache TTL must be 60-86400 seconds'),
    body('advanced.security.rateLimiting.maxRequests').optional().isInt({ min: 10, max: 1000 }).withMessage('Rate limit max requests must be 10-1000'),
    body('advanced.security.rateLimiting.windowMinutes').optional().isInt({ min: 1, max: 60 }).withMessage('Rate limit window must be 1-60 minutes'),
    
    // Maintenance settings validation
    body('maintenance.maintenanceMessage').optional().isLength({ max: 500 }).withMessage('Maintenance message must not exceed 500 characters'),
    body('maintenance.allowedIPs').optional().isArray().withMessage('Allowed IPs must be an array'),
    body('maintenance.autoBackup.frequency').optional().isIn(['daily', 'weekly', 'monthly']).withMessage('Invalid backup frequency'),
    body('maintenance.autoBackup.retention').optional().isInt({ min: 1, max: 365 }).withMessage('Backup retention must be 1-365 days')
  ],
  handleValidationErrors,
  webSettingsController.updateSettings
);

// PUT /api/v1/web-settings/:hotelId/section/:section - Update specific settings section
router.put('/:hotelId/section/:section',
  [
    param('hotelId').isMongoId().withMessage('Valid hotel ID is required'),
    param('section').isIn(['general', 'booking', 'payment', 'seo', 'integrations', 'theme', 'advanced', 'maintenance']).withMessage('Invalid settings section')
  ],
  handleValidationErrors,
  webSettingsController.updateSection
);

// POST /api/v1/web-settings/:hotelId/test - Test settings configuration
router.post('/:hotelId/test',
  [
    param('hotelId').isMongoId().withMessage('Valid hotel ID is required'),
    body('type').isIn(['payment_gateway', 'email_marketing', 'google_analytics', 'facebook_pixel']).withMessage('Invalid test type'),
    body('config').isObject().withMessage('Configuration object is required')
  ],
  handleValidationErrors,
  webSettingsController.testSettings
);

// GET /api/v1/web-settings/:hotelId/export - Export settings
router.get('/:hotelId/export',
  [
    param('hotelId').isMongoId().withMessage('Valid hotel ID is required'),
    query('format').optional().isIn(['json']).withMessage('Invalid export format')
  ],
  handleValidationErrors,
  webSettingsController.exportSettings
);

// POST /api/v1/web-settings/:hotelId/import - Import settings
router.post('/:hotelId/import',
  [
    param('hotelId').isMongoId().withMessage('Valid hotel ID is required'),
    body().isObject().withMessage('Settings data is required')
  ],
  handleValidationErrors,
  webSettingsController.importSettings
);

// POST /api/v1/web-settings/:hotelId/preview - Generate settings preview
router.post('/:hotelId/preview',
  [
    param('hotelId').isMongoId().withMessage('Valid hotel ID is required'),
    body().isObject().withMessage('Preview data is required')
  ],
  handleValidationErrors,
  webSettingsController.previewSettings
);

// POST /api/v1/web-settings/:hotelId/reset - Reset settings to default
router.post('/:hotelId/reset',
  [
    param('hotelId').isMongoId().withMessage('Valid hotel ID is required'),
    body('confirm').equals('RESET').withMessage('Confirmation required: must send "confirm": "RESET"')
  ],
  handleValidationErrors,
  webSettingsController.resetToDefault
);

// Error handling middleware
router.use((error, req, res, next) => {
  console.error('Web Settings API Error:', error);
  res.status(500).json({
    success: false,
    message: 'Internal server error',
    error: process.env.NODE_ENV === 'development' ? error.message : 'Something went wrong'
  });
});

export default router;